import "./detail.css";
import React from "react";

export default function Detail() {
  return (
    <div className="detail-container">
      <div className="detail-container-main"></div>
    </div>
  );
}
