import React from 'react';

export default function Notification() {

    return(
        <h1>Hello Notification</h1>
    )
}